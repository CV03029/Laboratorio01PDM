package ues.fia.cv03029_labevaluado1.ui.parte1;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import ues.fia.cv03029_labevaluado1.R;


public class Parte1Fragment extends Fragment {

    EditText edtnombre;
    EditText edtcarnet;


     @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         View view = inflater.inflate(R.layout.fragment_parte1, container, false);
         edtnombre = view.findViewById(R.id.editnombre);
         edtcarnet = view.findViewById(R.id.editcarnet);

         Button button = (Button) view.findViewById(R.id.btnparte1);

         button.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 String nombre = edtnombre.getText().toString();
                 String carnet = edtcarnet.getText().toString();
                 if(nombre.isEmpty()||carnet.isEmpty()||nombre.equals("ingrese su nombre")||carnet.equals("ingrese su carnet")){
                     Toast.makeText(view.getContext(),"Debe completar los datos de nombre y/o carnet",Toast.LENGTH_SHORT).show();
                 }else
                 {
                     Toast.makeText(view.getContext(),"Nombre: "+nombre +"\n"+ "Carnet: " + carnet,Toast.LENGTH_SHORT).show();
                 }

             }
         });

     return view;
     }
}