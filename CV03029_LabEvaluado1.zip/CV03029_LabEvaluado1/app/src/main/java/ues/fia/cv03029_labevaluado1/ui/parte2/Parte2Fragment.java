package ues.fia.cv03029_labevaluado1.ui.parte2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import ues.fia.cv03029_labevaluado1.R;


public class Parte2Fragment extends Fragment {

    EditText edtsueldo;
    Double isss;
    Double afp;
    Double renta;
    Double seguro;
    Double neto;
    Double sueldouble;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_parte2, container, false);

        edtsueldo = view.findViewById(R.id.editbruto);

        Button button = (Button) view.findViewById(R.id.btncalcular);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String sueldo = edtsueldo.getText().toString();
                if(sueldo.isEmpty()){
                    Toast.makeText(view.getContext(),"Debe introducir una cantidad",Toast.LENGTH_SHORT).show();
                }else{
                    sueldouble = Double.parseDouble(sueldo.toString());
                    Double isss = sueldouble * 0.03;
                    Double afp = sueldouble * 0.0725;
                      if(sueldouble>900){
                          Double seguro = sueldouble * 0.15;
                      }else{Double seguro = 0.0;}

                    if(sueldouble>0 && sueldouble<=550){
                        Double renta = 0.0;
                    }else if(sueldouble > 550 && sueldouble<=800){
                        Double renta = sueldouble * 0.01;
                    }else if(sueldouble >800 && sueldouble<=2500){
                        Double renta = sueldouble * 0.02;
                    }else if(sueldouble>2500){
                        Double renta = sueldouble * 0.03;
                    }

                    neto = sueldouble-isss-afp-seguro-renta;
                }



             }

        });
     return view;
    }
}